# Source notices: xray_anchor_v2.csv

`xray_anchor_v2.csv` is the verified anchor of the notebook
[Santa 2026 | The Elf Calculator X-Ray](https://www.kaggle.com/code/lucifer19/santa-2026-the-elf-calculator-x-ray), Version 2.

- 141,361 instructions over 1,000 programs, sha256 `dec43a70903bd17c7fd0fd5118bbf9f15194fcf9735ee17c3abb59589a137d73`.
- Every program was replayed under the official rules (registers, exact division, value range, coverage, length).
- It is a per-puzzle minimum over public notebook outputs of the Santa 2026 competition plus a few programs
  shortened by this notebook's cone re-solve. No competition data (`puzzles.csv`) is included.
- The table counts, for each public notebook output, the puzzles where it reaches the anchor's length (ties count for
  every file). It says where the programs can be found, not who invented them: the top files merge each other, so
  please see each notebook's own credits too.

| puzzles at anchor length | public notebook output |
|---|---|
| 998 | [Ángel Jacinto Sánchez Ruiz](https://www.kaggle.com/code/sacuscreed/public-merge) |
| 997 | [Hanif Noer Rofiq](https://www.kaggle.com/code/hanifnoerrofiq/santa-2026-elf-calculator-verified-portfolio) |
| 997 | [Roman Rozen](https://www.kaggle.com/code/romanrozen/santa-2026-icefire-strong-start) |
| 992 | [Vladislav Lavrentev](https://www.kaggle.com/code/lightningv08/santa-2026-shared-intermediates-cuda-cofactors) |
| 992 | [Pablo Diego Pereira](https://www.kaggle.com/code/pablodiegoo/santa-2026-deterministic-atlas-solver) |
| 992 | [Nilanjan Saha](https://www.kaggle.com/code/nilanjansaha123/best-of-public-elf-optimizer) |
| 988 | [Sargis Khachatryan](https://www.kaggle.com/code/avazaku/elf-calc-cross-trace-milp-arithmetic-cuts) |
| 974 | [Atakan Aldemir](https://www.kaggle.com/code/atakanaldemir/santa-2026-joint-recipes-for-large-puzzles) |
| 894 | [Bikram Basnet](https://www.kaggle.com/code/bikrambasnet1/santa-2026-arithmetic-graph-rewrites) |
| 2 (only here) | this notebook's cone re-solve: scored_0284, scored_0577 |

The programs keep their authors' terms; public Kaggle notebooks are released under Apache 2.0.
Please upvote the original notebooks.
