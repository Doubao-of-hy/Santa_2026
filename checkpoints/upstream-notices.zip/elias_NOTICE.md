# Notice

These programs for the 1,000 scored puzzles of Santa 2026 - The Elf Calculator score 142,856.
They were built from public work released under the Apache License 2.0:

- konbu17, Santa 2026 Elf Calculator Programs (dataset, version 10, 143,161 instructions) and the notebook
  Santa 2026: Wider Dictionary + Portfolio, which contains Tony Li's beam-search solver from
  Elf Calculator With Register Reuse. 790 programs have the same length as in that dataset.
- Mizero Lucky Gall, Elf Calc | Cost-Aware Registers + Peephole Pass.
- thisray, Beam Search over a Two-Step Dictionary, which konbu17's sources.csv names for some programs.
  The columns public_method and public_setting in sources.csv repeat konbu17's entries.

The other 210 programs are shorter than in konbu17's version 10 by 305 instructions in total. They were
shortened by the authors of this dataset on top of the public programs.

This dataset is released under the Apache License 2.0 (https://www.apache.org/licenses/LICENSE-2.0).
`sources.csv` lists, for every puzzle, the instruction count and where the program comes from.
