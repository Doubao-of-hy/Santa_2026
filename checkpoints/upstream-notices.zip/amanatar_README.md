# Santa 2026: SOTA 143,134 Verified Solution Bank
This dataset contains the verified 143,134-instruction straight-line programs for all 1,000 scored puzzles in Santa 2026: The Elf Calculator.
Achieved via monotonic multi-solver fusion, signed quotient-remainder beam search, Belady register allocation, and DAG graph compaction passes.
